const REDIS_URI ='127.0.0.1';
const REDIS_PORT =6379;

module.exports={
    REDIS_URI,
    REDIS_PORT
}